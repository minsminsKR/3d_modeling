Mixamo upload package for job 97669716-d587-4827-9dfc-5aa1ddb0dafd

1. Open https://www.mixamo.com/
2. Upload this ZIP, or upload the OBJ/GLB inside it if Mixamo rejects ZIP.
3. Complete Auto-Rigger marker placement in Mixamo.
4. Choose an animation and download FBX.
5. Upload the downloaded FBX back to this job page.

Note: Mixamo is an Adobe web service. This app does not store Adobe credentials or automate login.
